package interfaces;

public interface IMedalla {

    String getNameMedalla();
    void setNameMedalla(String nameMedalla);

    String getDescripcion();
    void setDescripcion(String descripcion);
}
